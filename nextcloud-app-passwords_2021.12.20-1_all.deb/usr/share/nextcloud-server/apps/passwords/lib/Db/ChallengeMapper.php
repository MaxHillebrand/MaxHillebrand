<?php

namespace OCA\Passwords\Db;

/**
 * Class ChallengeMapper
 *
 * @package OCA\Passwords\Db
 */
class ChallengeMapper extends AbstractMapper {
    const TABLE_NAME = 'passwords_challenge';
}